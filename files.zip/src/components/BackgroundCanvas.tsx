import { useEffect, useRef } from "react";
export default function BackgroundCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    const ctx = canvas.getContext("2d")!;
    let frame = 0;
    function draw() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < 90; i++) {
        ctx.strokeStyle = `rgba(0,255,0,${0.2 + Math.sin(frame / 20 + i) * 0.2})`;
        ctx.beginPath();
        ctx.arc(
          Math.sin(frame / 50 + i) * canvas.width/2 + canvas.width/2,
          Math.cos(frame / 60 + i) * canvas.height/2 + canvas.height/2,
          20 + Math.sin(frame / 30 + i) * 10,
          0, 2 * Math.PI
        );
        ctx.stroke();
      }
      frame++;
      requestAnimationFrame(draw);
    }
    draw();
  }, []);
  return (
    <canvas
      ref={ref}
      width={window.innerWidth}
      height={window.innerHeight}
      style={{
        position: "fixed",
        top: 0, left: 0, zIndex: 1,
        pointerEvents: "none"
      }}
    />
  );
}