export default function DownloadList({ downloads }) {
  return (
    <ul className="mt-4">
      {downloads.map((dl, i) => (
        <li key={i} className="bg-gray-900 text-green-200 rounded mb-2 p-4 flex justify-between items-center">
          <div>
            <div className="font-bold">{dl.name}</div>
            <div className="text-sm">{dl.description}</div>
            <div className="text-xs text-green-400">{dl.category}</div>
          </div>
          <a
            href={dl.url}
            download
            className="bg-green-700 px-3 py-1 rounded text-white hover:bg-green-600"
          >
            Download
          </a>
        </li>
      ))}
    </ul>
  );
}