import { Link, useLocation } from "react-router-dom";
export default function Navbar() {
  const { pathname } = useLocation();
  return (
    <nav className="fixed w-full top-0 z-20 bg-black bg-opacity-90 text-green-400 px-4 py-2 flex gap-8 shadow-lg">
      <Link to="/" className={`font-bold hover:text-green-200 ${pathname === "/" ? "underline" : ""}`}>Filevoult</Link>
      <Link to="/docs" className={pathname === "/docs" ? "underline" : ""}>Docs</Link>
      <Link to="/downloads" className={pathname === "/downloads" ? "underline" : ""}>Downloads</Link>
      <Link to="/admin" className={pathname === "/admin" ? "underline" : ""}>Admin</Link>
    </nav>
  );
}