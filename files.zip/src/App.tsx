import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Docs from "./pages/Docs";
import Downloads from "./pages/Downloads";
import Admin from "./pages/Admin";
import BackgroundCanvas from "./components/BackgroundCanvas";

export default function App() {
  return (
    <Router>
      <BackgroundCanvas />
      <Navbar />
      <div className="relative z-10 pt-16">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/docs" element={<Docs />} />
          <Route path="/downloads" element={<Downloads />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </div>
    </Router>
  );
}