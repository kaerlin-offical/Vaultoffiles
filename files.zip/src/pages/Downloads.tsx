import { useEffect, useState } from "react";
export default function Downloads() {
  const [downloads, setDownloads] = useState([]);
  useEffect(() => {
    const saved = localStorage.getItem("filevoult_downloads");
    setDownloads(saved ? JSON.parse(saved) : []);
  }, []);
  return (
    <div className="max-w-2xl mx-auto mt-32 p-8 bg-black bg-opacity-70 rounded shadow">
      <h2 className="text-green-400 font-bold text-2xl mb-4">Downloads</h2>
      <ul>
        {downloads.length === 0 && <li className="text-green-300">Noch keine Dateien vorhanden.</li>}
        {downloads.map((dl, i) => (
          <li key={i} className="bg-gray-900 text-green-200 rounded mb-2 p-4 flex justify-between items-center">
            <div>
              <div className="font-bold">{dl.name}</div>
              <div className="text-sm">{dl.description}</div>
              <div className="text-xs text-green-400">{dl.category}</div>
            </div>
            <a href={dl.url} download className="bg-green-700 px-3 py-1 rounded text-white hover:bg-green-600">Download</a>
          </li>
        ))}
      </ul>
    </div>
  );
}