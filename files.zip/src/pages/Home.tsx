export default function Home() {
  return (
    <div className="max-w-xl mx-auto mt-32 bg-black bg-opacity-70 p-8 rounded shadow">
      <h1 className="text-green-400 font-bold text-4xl mb-4">Filevoult</h1>
      <p className="text-green-200 mb-2 text-lg">Dein schwarzes, grünes File- und Download-Portal.</p>
      <ul className="list-disc pl-5 text-green-300">
        <li>Downloads mit Kategorien</li>
        <li>Admin-Upload & Verwaltung</li>
        <li>Jeder kann alles herunterladen</li>
        <li>API-Dokumentation</li>
      </ul>
    </div>
  );
}