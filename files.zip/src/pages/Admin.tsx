import { useEffect, useState } from "react";

export default function Admin() {
  const [downloads, setDownloads] = useState([]);
  const [categories, setCategories] = useState(["All"]);
  const [file, setFile] = useState(null);
  const [desc, setDesc] = useState("");
  const [cat, setCat] = useState("All");
  const [newCat, setNewCat] = useState("");
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);

  // Load data from localStorage
  useEffect(() => {
    const savedDownloads = localStorage.getItem("filevoult_downloads");
    if (savedDownloads) setDownloads(JSON.parse(savedDownloads));
    const savedCategories = localStorage.getItem("filevoult_categories");
    if (savedCategories) setCategories(JSON.parse(savedCategories));
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem("filevoult_downloads", JSON.stringify(downloads));
  }, [downloads]);
  useEffect(() => {
    localStorage.setItem("filevoult_categories", JSON.stringify(categories));
  }, [categories]);

  // Simple password protection (for demo; use real auth for production!)
  function handleLogin(e) {
    e.preventDefault();
    if (password === "armin123") setLoggedIn(true);
    else alert("Falsches Passwort");
  }

  function handleUpload(e) {
    e.preventDefault();
    if (!file) return;
    const url = URL.createObjectURL(file);
    setDownloads([...downloads, { name: file.name, description: desc, category: cat, url }]);
    setDesc(""); setFile(null);
  }

  function handleCategoryAdd(e) {
    e.preventDefault();
    if (newCat && !categories.includes(newCat)) {
      setCategories([...categories, newCat]);
      setNewCat("");
    }
  }

  if (!loggedIn) {
    return (
      <div className="max-w-sm mx-auto mt-32 bg-black bg-opacity-70 p-8 rounded shadow">
        <h2 className="text-green-400 font-bold text-xl mb-2">Admin Login</h2>
        <form onSubmit={handleLogin} className="flex flex-col gap-2">
          <input
            type="password"
            placeholder="Passwort"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="bg-gray-900 text-green-200 p-2 rounded"
          />
          <button className="bg-green-700 text-white px-4 py-2 rounded mt-2">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto mt-32 bg-black bg-opacity-70 p-8 rounded shadow">
      <h2 className="text-green-400 font-bold text-xl mb-2">Admin Panel</h2>
      <form onSubmit={handleUpload} className="flex flex-col gap-2 mb-8">
        <label className="text-green-300">Datei hochladen:</label>
        <input type="file" onChange={e => setFile(e.target.files[0])} />
        <input
          type="text"
          placeholder="Beschreibung"
          value={desc}
          onChange={e => setDesc(e.target.value)}
          className="bg-gray-900 text-green-200 p-2 rounded"
        />
        <select value={cat} onChange={e => setCat(e.target.value)} className="bg-gray-900 text-green-200 p-2 rounded">
          {categories.map((c, i) => <option key={i}>{c}</option>)}
        </select>
        <button className="bg-green-700 text-white px-4 py-2 rounded mt-2">Hochladen</button>
      </form>
      <form onSubmit={handleCategoryAdd} className="flex gap-2 mb-8">
        <input
          type="text"
          placeholder="Neue Kategorie"
          value={newCat}
          onChange={e => setNewCat(e.target.value)}
          className="bg-gray-900 text-green-200 p-2 rounded"
        />
        <button className="bg-green-700 text-white px-4 py-2 rounded">Kategorie erstellen</button>
      </form>
      <h3 className="text-green-300 font-bold mb-2">Dateien</h3>
      <ul>
        {downloads.map((dl, i) => (
          <li key={i} className="bg-gray-900 text-green-200 rounded mb-2 p-2">
            {dl.name} ({dl.category}) - {dl.description}
          </li>
        ))}
      </ul>
    </div>
  );
}