export default function Docs() {
  return (
    <div className="max-w-2xl mx-auto mt-32 p-8 bg-black bg-opacity-70 rounded shadow">
      <h2 className="text-green-400 font-bold text-2xl mb-4">API Dokumentation</h2>
      <div className="text-green-200 space-y-2">
        <div>
          <span className="font-mono bg-gray-900 p-1 rounded text-green-300">GET /api/downloads</span><br />
          Liefert alle verfügbaren Downloads (öffentlicher Zugriff).
        </div>
        <div>
          <span className="font-mono bg-gray-900 p-1 rounded text-green-300">POST /api/upload</span><br />
          Nur für Admin, lädt eine Datei hoch.
        </div>
        <div>
          <span className="font-mono bg-gray-900 p-1 rounded text-green-300">GET /api/categories</span><br />
          Gibt alle Kategorien zurück.
        </div>
      </div>
    </div>
  );
}