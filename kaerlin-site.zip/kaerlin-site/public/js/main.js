// Canvas particle animation for hero
(function(){
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let dpr = window.devicePixelRatio || 1;
  let W, H;
  function resize(){
    const rect = canvas.getBoundingClientRect();
    W = rect.width; H = rect.height;
    canvas.width = Math.floor(W * dpr);
    canvas.height = Math.floor(H * dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  window.addEventListener('resize', resize, {passive:true});
  resize();

  const particles = Array.from({length: 90}).map(()=> ({
    x: Math.random()*W,
    y: Math.random()*H,
    vx: (Math.random()-0.5)*0.8,
    vy: (Math.random()-0.5)*0.8
  }));

  function step(){
    ctx.clearRect(0,0,W,H);
    // glow grid
    for(let i=0;i<particles.length;i++){
      const p = particles[i];
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1;
      if (p.y < 0 || p.y > H) p.vy *= -1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 1.6, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(0,255,136,0.8)';
      ctx.fill();
    }
    // connect nearby
    for(let i=0;i<particles.length;i++){
      for(let j=i+1;j<particles.length;j++){
        const a = particles[i], b = particles[j];
        const dx = a.x-b.x, dy=a.y-b.y;
        const dist2 = dx*dx+dy*dy;
        if (dist2 < 140*140){
          const alpha = 1 - Math.sqrt(dist2)/140;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.strokeStyle = 'rgba(0,255,136,'+ (0.12*alpha) +')';
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(step);
  }
  step();
})();
