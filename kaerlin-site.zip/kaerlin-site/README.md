# Kaerlin Website

Multi-page site (Home, Docs, Downloads) with a black/green theme, canvas animations, and an admin-only upload dashboard with categories.

## Features
- **Pages**: `/` (Home), `/docs`, `/downloads` (public), `/admin` (protected)
- **Admin uploads**: Only you can upload; visitors can download
- **Categories**: Upload files into categories; downloads page groups by category
- **Responsive**: Mobile, tablet, desktop
- **Design**: Black background, green accents; animated canvas header
- **Tech**: Node.js + Express, EJS templates, Multer for uploads, express-session for auth, bcrypt for password

## Quick Start
1. Install Node.js >= 18.
2. Extract the ZIP and open a terminal in the project folder.
3. Copy `.env.example` to `.env` and edit:
   - Set a strong `SESSION_SECRET`.
   - Set `ADMIN_PASSWORD_HASH` to the bcrypt hash of your chosen password (see below).
4. Install dependencies:
   ```bash
   npm install
   ```
5. Run:
   ```bash
   npm start
   ```
6. Visit http://localhost:3000

### Create a bcrypt hash
```bash
node -e "require('bcrypt').hash(process.argv[1], 10).then(h=>console.log(h))" yourStrongPasswordHere
```
Copy the printed hash into `.env` as `ADMIN_PASSWORD_HASH`.

### File storage
- Uploaded files are stored under `public/downloads/<category>/filename` and are publicly downloadable.
- Categories are directories under `public/downloads`. You can create a new category during upload.

### Security notes
- This is a minimal, self-hosted admin panel using password auth and sessions.
- Use HTTPS in production and set `SESSION_SECRET` to a strong random value.
- Optionally restrict file types via `ALLOWED_EXTENSIONS` in `.env`.

### Scripts
- `npm start` - start the server on port 3000
- `npm run dev` - start with nodemon (auto-restart on changes)

