\
/* Kaerlin multi-page site */
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 3000;

const ROOT = __dirname;
const DOWNLOADS_DIR = path.join(ROOT, 'public', 'downloads');
const TMP_DIR = path.join(ROOT, 'uploads', 'tmp');
if (!fs.existsSync(DOWNLOADS_DIR)) fs.mkdirSync(DOWNLOADS_DIR, {recursive:true});
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, {recursive:true});

app.set('view engine', 'ejs');
app.set('views', path.join(ROOT, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Sessions
app.use(session({
  name: 'kaerlin.sid',
  secret: process.env.SESSION_SECRET || 'dev_secret_change_me',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 8 // 8 hours
  }
}));

// Static
app.use(express.static(path.join(ROOT, 'public'), {
  extensions: ['html'],
  setHeaders(res, filePath) {
    // Basic security headers
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  }
}));

// Utilities
function listCategories() {
  if (!fs.existsSync(DOWNLOADS_DIR)) return [];
  return fs.readdirSync(DOWNLOADS_DIR, {withFileTypes: true})
    .filter(d => d.isDirectory())
    .map(d => d.name).sort();
}

function listFilesGroupedByCategory() {
  const groups = {};
  const cats = listCategories();
  cats.forEach(cat => {
    const catPath = path.join(DOWNLOADS_DIR, cat);
    const files = fs.readdirSync(catPath, {withFileTypes: true})
      .filter(f => f.isFile())
      .map(f => ({
        name: f.name,
        size: fs.statSync(path.join(catPath, f.name)).size,
        mtime: fs.statSync(path.join(catPath, f.name)).mtime
      }))
      .sort((a,b)=> b.mtime - a.mtime);
    groups[cat] = files;
  });
  return groups;
}

function sanitizeFilename(name) {
  // Remove path components and risky chars
  return path.basename(name).replace(/[^\w.\-()+\s]/g, '_');
}

function extAllowed(filename) {
  const cfg = (process.env.ALLOWED_EXTENSIONS || '').toLowerCase().split(',').map(s=>s.trim()).filter(Boolean);
  if (cfg.length === 0) return true;
  const ext = path.extname(filename).toLowerCase().replace(/^\./,'');
  return cfg.includes(ext);
}

// Multer storage with dynamic destination based on category
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const category = (req.body.category && req.body.category.trim()) || (req.body.newCategory && req.body.newCategory.trim());
    const safeCat = category && category.replace(/[^\w\-()+\s]/g, '_');
    const target = safeCat ? path.join(DOWNLOADS_DIR, safeCat) : DOWNLOADS_DIR;
    fs.mkdirSync(target, {recursive:true});
    cb(null, target);
  },
  filename: (req, file, cb) => {
    const safe = sanitizeFilename(file.originalname);
    cb(null, safe);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 1024 * 1024 * 1024 }, // 1 GB
  fileFilter: (req, file, cb) => {
    if (!extAllowed(file.originalname)) {
      return cb(new Error('File extension not allowed'));
    }
    cb(null, true);
  }
});

// Auth middleware
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) return next();
  res.redirect('/admin/login?next=' + encodeURIComponent(req.originalUrl));
}

// Routes: Public pages
app.get('/', (req, res) => {
  res.render('index', { title: 'Kaerlin — Home' });
});

app.get('/docs', (req, res) => {
  res.render('docs', { title: 'Kaerlin — Docs' });
});

app.get('/downloads', (req, res) => {
  const groups = listFilesGroupedByCategory();
  res.render('downloads', { title: 'Kaerlin — Downloads', groups });
});

// Admin
app.get('/admin/login', (req, res) => {
  res.render('admin_login', { title: 'Admin Login', error: null });
});

app.post('/admin/login', async (req, res) => {
  const { password } = req.body;
  const hash = process.env.ADMIN_PASSWORD_HASH || '';
  try {
    const ok = await bcrypt.compare(password || '', hash);
    if (ok) {
      req.session.authenticated = true;
      return res.redirect('/admin');
    }
  } catch(e) {}
  res.status(401).render('admin_login', { title: 'Admin Login', error: 'Invalid password' });
});

app.get('/admin/logout', (req, res) => {
  req.session.destroy(()=>{
    res.redirect('/');
  });
});

app.get('/admin', requireAuth, (req, res) => {
  const cats = listCategories();
  res.render('admin_dashboard', { title: 'Admin — Uploads', cats, message: null, error: null });
});

app.post('/admin/upload', requireAuth, (req, res) => {
  const handler = upload.array('files', 20);
  handler(req, res, (err) => {
    const cats = listCategories();
    if (err) {
      return res.status(400).render('admin_dashboard', { title: 'Admin — Uploads', cats, message: null, error: err.message });
    }
    return res.render('admin_dashboard', { title: 'Admin — Uploads', cats, message: 'Upload successful.', error: null });
  });
});

// 404
app.use((req, res) => {
  res.status(404).render('docs', { title: 'Not Found' });
});

app.listen(PORT, () => {
  console.log(`Kaerlin running on http://localhost:${PORT}`);
});
